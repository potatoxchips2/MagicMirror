// eslint-disable-next-line no-unused-vars, no-undef
class ViewWeek extends ViewCell {}
